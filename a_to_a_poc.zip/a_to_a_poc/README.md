# AutoGen Agent↔Agent PoC

## Run
1) `python -m venv .venv && . .venv/Scripts/activate` (Windows) or `source .venv/bin/activate`
2) `pip install -r requirements.txt`
3) Copy `.env.example` to `.env` and fill your key(s).
4) `python main.py`

Expected: Console me streaming messages dikhenge — Planner plan banayega, Coder code likhega, `run_python()` tool call hoga, aur final "DONE ✅" ke sath report print hogi.
