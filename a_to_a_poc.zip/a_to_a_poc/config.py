import os
from dotenv import load_dotenv
from typing import Literal, Optional

# AutoGen model clients
from autogen_ext.models.openai import OpenAIChatCompletionClient
from autogen_ext.models.openai import AzureOpenAIChatCompletionClient

load_dotenv()

def get_model_client():
    """
    Detect OpenAI vs Azure OpenAI from env and return a ChatCompletionClient.
    """
    # Prefer Azure if endpoint present
    azure_endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
    azure_key = os.getenv("AZURE_OPENAI_API_KEY")
    if azure_endpoint and azure_key:
        deployment = os.getenv("AZURE_OPENAI_DEPLOYMENT", "gpt-4o")
        api_version = os.getenv("AZURE_OPENAI_API_VERSION", "2024-08-01-preview")
        return AzureOpenAIChatCompletionClient(
            api_key=azure_key,
            api_version=api_version,
            azure_endpoint=azure_endpoint,
            model=deployment,  # In Azure client, 'model' is your deployment name
        )

    # Otherwise OpenAI
    openai_key = os.getenv("OPENAI_API_KEY")
    if not openai_key:
        raise RuntimeError(
            "No model credentials found. Set either OPENAI_API_KEY or Azure OpenAI env vars."
        )

    # You can switch model to gpt-4o-mini for cost
    return OpenAIChatCompletionClient(
        model="gpt-4o",
        api_key=openai_key,
    )
