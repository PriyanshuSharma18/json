import asyncio
import contextlib
import io
import os
from typing import Any, Dict

class CodeRunError(Exception):
    pass

# ---- SAFE HELPERS ------------------------------------------------------------

# Only allow importing these pure-Python stdlib modules
_ALLOWED_IMPORTS = {"csv", "json", "math"}

def _limited_import(name, globals=None, locals=None, fromlist=(), level=0):
    # Disallow anything outside allowlist
    root = name.split(".", 1)[0]
    if root not in _ALLOWED_IMPORTS:
        raise ImportError(f"module '{name}' not allowed")
    return __import__(name, globals, locals, fromlist, level)

# Only allow reading THIS file in CWD (no writes, no traversal)
_ALLOWED_FILES = {"sample_data.csv"}

def _safe_open(file, mode="r", *args, **kwargs):
    if mode not in ("r", "rt"):  # read-only text
        raise PermissionError("only read mode allowed")
    # Normalize and block path traversal; require file to be in allowed set
    if isinstance(file, str):
        fname = os.path.basename(file)
        if fname not in _ALLOWED_FILES:
            raise PermissionError(f"file '{file}' is not allowed")
        file = fname  # force local basename
    else:
        # Non-string paths not allowed
        raise PermissionError("invalid file path type")
    return open(file, mode, *args, **kwargs)

# ---- EXECUTOR ----------------------------------------------------------------

async def run_python(code: str) -> Dict[str, Any]:
    """
    Execute model-generated Python with a very small allowlist.
    - Allows: print, len, range, sum, min, max, sorted, int, float
    - Allows: import of csv/json/math only (via limited __import__)
    - Allows: open('sample_data.csv','r') only
    - Captures stdout/stderr
    - 8s timeout
    NOTE: Demo-only. Not a real security sandbox.
    """
    allowed_builtins = {
        "print": print,
        "len": len,
        "range": range,
        "sum": sum,
        "min": min,
        "max": max,
        "sorted": sorted,
        "int": int,
        "float": float,
        "__import__": _limited_import,
        "open": _safe_open,
    }

    safe_globals = {"__builtins__": allowed_builtins}
    safe_locals: Dict[str, Any] = {}

    stdout_buf = io.StringIO()
    stderr_buf = io.StringIO()

    async def _run():
        try:
            with contextlib.redirect_stdout(stdout_buf), contextlib.redirect_stderr(stderr_buf):
                exec(code, safe_globals, safe_locals)  # noqa: S102 (demo)
        except Exception as e:
            raise CodeRunError(str(e)) from e

    try:
        await asyncio.wait_for(_run(), timeout=8)
    except asyncio.TimeoutError:
        return {"ok": False, "stdout": stdout_buf.getvalue(), "stderr": "Execution timed out (>8s)."}
    except CodeRunError as e:
        return {"ok": False, "stdout": stdout_buf.getvalue(), "stderr": str(e)}

    return {"ok": True, "stdout": stdout_buf.getvalue(), "stderr": stderr_buf.getvalue()}
