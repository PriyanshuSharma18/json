import asyncio
from config import get_model_client
from agents import build_team, run_team

USER_TASK = (
    "Read 'sample_data.csv', compute total revenue (unit_price*quantity summed), "
    "and print a concise report like: 'Total revenue: <amount>'."
)

async def main():
    model_client = get_model_client()
    team = build_team(model_client)
    await run_team(team, USER_TASK)
    await model_client.close()

if __name__ == "__main__":
    asyncio.run(main())
