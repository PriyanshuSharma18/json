from autogen_agentchat.agents import AssistantAgent
from autogen_agentchat.conditions import TextMentionTermination, MaxMessageTermination
from autogen_agentchat.teams import RoundRobinGroupChat
from autogen_agentchat.ui import Console



from typing import List

# Our tool
from tools import run_python

def build_team(model_client) -> RoundRobinGroupChat:
    """
    Create a Planner + Coder pair that collaborate in a group chat.
    Coder can call the run_python tool to execute code.
    """

    planner = AssistantAgent(
        name="planner",
        system_message=(
            "You are Planner. Break the user task into 2-5 concise steps. "
            "Prefer simple algorithms and minimal dependencies. "
            "End your plan with a short checklist prefixed 'PLAN:'."
        ),
        model_client=model_client,
        model_client_stream=True,
    )

    coder = AssistantAgent(
        name="coder",
        system_message=(
            "You are Coder. Write minimal, correct Python code satisfying the plan. "
            "Use CSV from file 'sample_data.csv' if needed. "
            "When ready, call the tool run_python(code:str) to execute. "
            "After execution, summarize result and end with 'DONE ✅'."
        ),
        tools=[run_python],        # <-- Tool exposure
        model_client=model_client,
        model_client_stream=True,
        reflect_on_tool_use=True,  # ask LLM to verify/retry tool usage
    )

    # Termination: stop when coder says DONE ✅, or after 8 total messages
    termination = TextMentionTermination("DONE ✅") | MaxMessageTermination(8)

    team = RoundRobinGroupChat(
        participants=[planner, coder],
        termination_condition=termination,   # sirf ek argument
        # fallback_termination=...  <-- hata do
    )
    return team

async def run_team(team: RoundRobinGroupChat, user_task: str):
    """
    Stream the multi-agent conversation to console.
    """
    stream = team.run_stream(task=user_task)
    await Console(stream)  # pretty prints conversation to terminal
