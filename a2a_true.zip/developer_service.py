# developer_service.py
import os
import logging
from typing import Optional, Literal

from fastapi import FastAPI
from pydantic import BaseModel
from dotenv import load_dotenv

import autogen

from config import get_azure_openai_config
from a2a_client import load_agent_card, call_remote_reviewer

load_dotenv()

# ------------------------------------------------------------
# Logging
# ------------------------------------------------------------
logger = logging.getLogger("developer_service")
logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(name)s | %(message)s")

# ------------------------------------------------------------
# Settings
# ------------------------------------------------------------
REVIEWER_API_KEY = os.getenv("REVIEWER_API_KEY", "dev-demo-key")
AGENT_CARD_PATH = os.getenv("REVIEWER_AGENT_CARD_PATH", "reviewer.agentcard.json")
MAX_REVISIONS = int(os.getenv("MAX_REVISIONS", "3"))

# ------------------------------------------------------------
# FastAPI app
# ------------------------------------------------------------
app = FastAPI(
    title="Developer A2A Agent",
    version="1.0.0",
    description="Hybrid FastAPI + AutoGen developer agent with dynamic A2A delegation.",
)

# ------------------------------------------------------------
# Build Developer (AutoGen) once at startup
# ------------------------------------------------------------
def build_developer():
    llm_config = get_azure_openai_config()
    return autogen.AssistantAgent(
        name="Developer",
        system_message=(
            "You are a senior Python developer. "
            "For tasks requiring code, write clean, correct, production-quality Python with docstrings and error handling. "
            "For general Q&A, reply directly and concisely in text. "
            "When asked to revise based on feedback, produce updated code only."
        ),
        llm_config=llm_config,
    )

developer_agent = build_developer()
agent_card = load_agent_card(AGENT_CARD_PATH)

# ------------------------------------------------------------
# Pydantic models
# ------------------------------------------------------------
class TaskIn(BaseModel):
    prompt: str

class ReviewTrace(BaseModel):
    status: Literal["APPROVED", "CHANGES_REQUIRED"]
    feedback: str

class TaskOut(BaseModel):
    handled_by: Literal["developer", "developer+reviewer"]
    output: str
    review_trace: Optional[list[ReviewTrace]] = None

# ------------------------------------------------------------
# Routing logic: decide if we should call Reviewer
# Two layers: LLM decision with a keyword fallback
# ------------------------------------------------------------
def should_delegate_to_reviewer(user_prompt: str) -> bool:
    # keyword fallback first
    keywords = ["code", "python", "function", "class", "bug", "refactor", "unit test", "write a script", "implement"]
    if any(k in user_prompt.lower() for k in keywords):
        return True

    # LLM-based decision
    judge_prompt = (
        "You are a router. Decide if this task requires code generation or code review. "
        "Reply with a single word ONLY: YES (if it needs code or code review) or NO (otherwise).\n\n"
        f"Task: {user_prompt}"
    )
    resp = developer_agent.generate_reply(messages=[{"role": "user", "content": judge_prompt}])
    text = resp if isinstance(resp, str) else resp.get("content", "")
    return "YES" in text.upper()

# ------------------------------------------------------------
# Developer helpers
# ------------------------------------------------------------
def developer_generate_code(task_prompt: str) -> str:
    reply = developer_agent.generate_reply(messages=[{"role": "user", "content": task_prompt}])
    return reply if isinstance(reply, str) else reply.get("content", "")

def developer_fix_code(current_code: str, feedback: str) -> str:
    prompt = (
        "You previously wrote this code:\n\n"
        f"{current_code}\n\n"
        "The reviewer provided feedback:\n\n"
        f"{feedback}\n\n"
        "Revise the code to fully address the feedback. Return only the updated code."
    )
    reply = developer_agent.generate_reply(messages=[{"role": "user", "content": prompt}])
    return reply if isinstance(reply, str) else reply.get("content", "")

def developer_answer_direct(user_prompt: str) -> str:
    reply = developer_agent.generate_reply(messages=[{"role": "user", "content": user_prompt}])
    return reply if isinstance(reply, str) else reply.get("content", "")

# ------------------------------------------------------------
# Main endpoint
# ------------------------------------------------------------
@app.post("/tasks", response_model=TaskOut)
def handle_task(body: TaskIn):
    user_prompt = body.prompt.strip()

    # 1) Decide whether to delegate
    delegate = should_delegate_to_reviewer(user_prompt)

    if not delegate:
        # Developer answers directly
        answer = developer_answer_direct(user_prompt)
        return TaskOut(handled_by="developer", output=answer)

    # 2) Generate code, then send to Reviewer, iterate until approved
    code = developer_generate_code(user_prompt)
    review_trace: list[ReviewTrace] = []

    for _ in range(MAX_REVISIONS):
        review_json = call_remote_reviewer(agent_card, REVIEWER_API_KEY, code)
        result = review_json.get("result", {})
        status = result.get("status", "CHANGES_REQUIRED")
        feedback = result.get("feedback", "")

        review_trace.append(ReviewTrace(status=status, feedback=feedback))

        if status == "APPROVED":
            return TaskOut(handled_by="developer+reviewer", output=code, review_trace=review_trace)

        # revise
        code = developer_fix_code(code, feedback)

    # if never approved, return last version with trace
    return TaskOut(handled_by="developer+reviewer", output=code, review_trace=review_trace)

@app.get("/health")
def health():
    return {"status": "ok"}
