# a2a_client.py
import json
import time
import uuid
import logging
from typing import Dict, Any
import requests
from requests import Response

logger = logging.getLogger("a2a_client")

def load_agent_card(path: str) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def post_with_retry(
    url: str,
    json_payload: Dict[str, Any],
    headers: Dict[str, str],
    retries: int = 3,
    backoff_sec: float = 1.0,
    timeout: int = 30,
) -> Response:
    for attempt in range(1, retries + 1):
        try:
            resp = requests.post(url, json=json_payload, headers=headers, timeout=timeout)
            if 200 <= resp.status_code < 300:
                return resp
            logger.warning(f"Attempt {attempt} failed: {resp.status_code} {resp.text}")
        except Exception as e:
            logger.warning(f"Attempt {attempt} exception: {e}")
        time.sleep(backoff_sec * attempt)
    raise RuntimeError(f"Failed to POST after {retries} attempts to {url}")

def call_remote_reviewer(agent_card: Dict[str, Any], api_key: str, code: str) -> Dict[str, Any]:
    endpoint = agent_card["api"]["endpoint"]
    header_name = agent_card["security"]["header"]
    headers = {"Content-Type": "application/json", header_name: api_key}
    payload = {
        "taskId": str(uuid.uuid4()),
        "params": {"capability": "code_review", "input": {"code": code}},
        "metadata": {"caller": "Developer", "agentCardVersion": agent_card["version"]}
    }
    resp = post_with_retry(endpoint, payload, headers)
    return resp.json()
