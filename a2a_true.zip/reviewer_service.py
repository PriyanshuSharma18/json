# reviewer_service.py
import os
import json
import logging
from typing import Literal, Optional, Dict, Any

from fastapi import FastAPI, Header, HTTPException, status, Depends
from pydantic import BaseModel, Field
from dotenv import load_dotenv

import autogen  # AutoGen agent inside the FastAPI process

load_dotenv()

# -------------------------------------------------------------------
# Config & Logging
# -------------------------------------------------------------------
SERVICE_VERSION = "1.1.0"
REQUIRED_API_KEY = os.getenv("REVIEWER_API_KEY", "dev-demo-key")

# Azure OpenAI (used by the AutoGen Reviewer agent)
AZURE_OPENAI_API_KEY = os.getenv("AZURE_OPENAI_API_KEY")
AZURE_OPENAI_ENDPOINT = os.getenv("AZURE_OPENAI_ENDPOINT")
AZURE_OPENAI_DEPLOYMENT_NAME = os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME", "gpt-4o")
AZURE_OPENAI_MODEL_NAME = os.getenv("AZURE_OPENAI_MODEL_NAME", "gpt-4o")
AZURE_OPENAI_API_VERSION = os.getenv("AZURE_OPENAI_API_VERSION", "2024-02-01")

logger = logging.getLogger("reviewer_service")
logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(name)s | %(message)s")

# -------------------------------------------------------------------
# FastAPI app
# -------------------------------------------------------------------
app = FastAPI(
    title="Reviewer A2A Agent",
    version=SERVICE_VERSION,
    description="A2A-compliant remote Reviewer agent (AutoGen + reflection).",
)

# -------------------------------------------------------------------
# Auth (Basic API Key via header)
# -------------------------------------------------------------------
def verify_api_key(x_api_key: Optional[str] = Header(None, alias="X-API-Key")):
    if x_api_key != REQUIRED_API_KEY:
        logger.warning("Unauthorized access attempt")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or missing API key",
        )

# -------------------------------------------------------------------
# A2A Task Schemas
# -------------------------------------------------------------------
class CodeReviewInput(BaseModel):
    code: str = Field(..., description="Python source to review")

class TaskParams(BaseModel):
    capability: Literal["code_review"]
    input: CodeReviewInput

class TaskRequest(BaseModel):
    taskId: str
    params: TaskParams
    metadata: dict = {}

class TaskResult(BaseModel):
    status: Literal["APPROVED", "CHANGES_REQUIRED"]
    feedback: str

class TaskResponse(BaseModel):
    taskId: str
    result: TaskResult
    agentVersion: str = SERVICE_VERSION

# -------------------------------------------------------------------
# Build the AutoGen Reviewer Agent (once)
# -------------------------------------------------------------------
def get_azure_openai_config() -> Dict[str, Any]:
    if not AZURE_OPENAI_API_KEY or not AZURE_OPENAI_ENDPOINT:
        logger.warning("Azure OpenAI env vars missing; make sure .env is set.")
    return {
        "config_list": [
            {
                "model": AZURE_OPENAI_MODEL_NAME,          # logical name
                "api_key": AZURE_OPENAI_API_KEY,
                "base_url": AZURE_OPENAI_ENDPOINT,
                "api_type": "azure",
                "api_version": AZURE_OPENAI_API_VERSION,
                "azure_deployment": AZURE_OPENAI_DEPLOYMENT_NAME,  # deployment id
            }
        ],
        "temperature": 0.0,
        "timeout": 60,
    }

def build_reviewer_agent():
    """
    Reviewer persona: Senior Python reviewer.
    Produces structured JSON outputs when asked.
    """
    llm_config = get_azure_openai_config()
    system_message = (
        "You are a senior Python code reviewer. Your job: analyze code for correctness, "
        "robustness, clarity, and best practices. Prefer actionable, specific feedback. "
        "You will be asked to first produce an ANALYSIS JSON with issues, then a DECISION JSON "
        "with 'APPROVED' or 'CHANGES_REQUIRED' and concise feedback bullets.\n\n"
        "Important:\n"
        "- Never execute code; reason from reading only.\n"
        "- Be precise. Mention missing docstrings, error handling, edge cases, and naming.\n"
        "- When asked for DECISION JSON, return ONLY valid JSON (no prose)."
    )
    return autogen.AssistantAgent(
        name="ReviewerAgent",
        system_message=system_message,
        llm_config=llm_config,
    )

reviewer_agent = build_reviewer_agent()

# -------------------------------------------------------------------
# Helper: safe JSON parse
# -------------------------------------------------------------------
def try_parse_json(text: str) -> Optional[Dict[str, Any]]:
    try:
        return json.loads(text)
    except Exception:
        # tolerate code fences or extra text
        try:
            # strip fences if present
            if "```" in text:
                inner = text.split("```")
                # pick the first JSON-looking chunk
                for chunk in inner:
                    chunk = chunk.strip()
                    if chunk.startswith("{") and chunk.endswith("}"):
                        return json.loads(chunk)
        except Exception:
            pass
    return None

# -------------------------------------------------------------------
# Reflection-based Review (P2: two passes)
# -------------------------------------------------------------------
def review_with_reflection(code: str) -> TaskResult:
    """
    Pass 1: ANALYSIS JSON (issues list with severity + suggestions)
    Pass 2: DECISION JSON (status + feedback)
    """
    # -------- Pass 1: Analysis --------
    analysis_prompt = (
        "Analyze the following Python code. Identify issues and suggestions.\n"
        "Return strictly this JSON:\n"
        "{\n"
        '  "summary": "one-paragraph high-level appraisal",\n'
        '  "issues": [\n'
        '    {"title":"string","severity":"low|medium|high","explanation":"string","suggestion":"string"}\n'
        "  ]\n"
        "}\n\n"
        f"CODE:\n{code}"
    )
    analysis_raw = reviewer_agent.generate_reply(messages=[{"role": "user", "content": analysis_prompt}])
    analysis_txt = analysis_raw if isinstance(analysis_raw, str) else analysis_raw.get("content", "")
    analysis_json = try_parse_json(analysis_txt) or {"summary": "", "issues": []}

    # Basic heuristic from analysis: if any high/medium issues touching correctness/robustness, require changes.
    has_blockers = any(
        (iss.get("severity") in ("high", "medium")) for iss in analysis_json.get("issues", [])
    )

    # -------- Pass 2: Decision --------
    decision_prompt = (
        "Based on this ANALYSIS JSON, decide APPROVED or CHANGES_REQUIRED. "
        "If any correctness or robustness issues exist (esp. missing error handling, invalid types, "
        "missing return contract, missing docstrings), choose CHANGES_REQUIRED.\n\n"
        "Return STRICT JSON only, exactly:\n"
        "{\n"
        '  "status": "APPROVED" | "CHANGES_REQUIRED",\n'
        '  "feedback": "Concise bullet list (use dashes) of concrete changes or, if approved, a brief note."\n'
        "}\n\n"
        f"ANALYSIS JSON:\n{json.dumps(analysis_json, ensure_ascii=False)}"
    )
    decision_raw = reviewer_agent.generate_reply(messages=[{"role": "user", "content": decision_prompt}])
    decision_txt = decision_raw if isinstance(decision_raw, str) else decision_raw.get("content", "")
    decision_json = try_parse_json(decision_txt)

    # Fallback if LLM didn't give clean JSON
    if not decision_json:
        status = "CHANGES_REQUIRED" if has_blockers else "APPROVED"
        feedback = (
            "- Address noted issues from analysis.\n- Add tests and docstrings."
            if status == "CHANGES_REQUIRED" else "Looks good. No changes required."
        )
        return TaskResult(status=status, feedback=feedback)

    status = decision_json.get("status", "CHANGES_REQUIRED")
    feedback = decision_json.get("feedback", "No feedback provided.")
    # Safety guard: enforce blockers heuristic if LLM returned APPROVED by mistake
    if has_blockers and status == "APPROVED":
        status = "CHANGES_REQUIRED"
        feedback = "- One or more medium/high severity issues found; please address them before approval."
    return TaskResult(status=status, feedback=feedback)

# -------------------------------------------------------------------
# A2A: synchronous task endpoint
# -------------------------------------------------------------------
@app.post("/a2a/tasks", response_model=TaskResponse, dependencies=[Depends(verify_api_key)])
def handle_task(req: TaskRequest):
    logger.info(f"Received task {req.taskId} with capability {req.params.capability}")
    if req.params.capability != "code_review":
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Unsupported capability '{req.params.capability}'"
        )
    code = req.params.input.code
    result = review_with_reflection(code)
    logger.info(f"Task {req.taskId} result: {result.status}")
    return TaskResponse(taskId=req.taskId, result=result, agentVersion=SERVICE_VERSION)
