# config.py
import os
from typing import Dict, Any
from dotenv import load_dotenv

load_dotenv()

def get_azure_openai_config() -> Dict[str, Any]:
    return {
        "config_list": [
            {
                "model": os.getenv("AZURE_OPENAI_MODEL_NAME", "gpt-4o"),
                "api_key": os.getenv("AZURE_OPENAI_API_KEY"),
                "base_url": os.getenv("AZURE_OPENAI_ENDPOINT"),
                "api_type": "azure",
                "api_version": os.getenv("AZURE_OPENAI_API_VERSION", "2024-02-01"),
                "azure_deployment": os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME", "gpt-4o")
            }
        ],
        "temperature": 0.2,
        "timeout": 60,
    }
