import os, uvicorn
from dotenv import load_dotenv
from a2a.server.apps import A2AStarletteApplication
from a2a.server.request_handlers import DefaultRequestHandler
from a2a.server.tasks import InMemoryTaskStore
from a2a.types import AgentCard, AgentSkill, AgentCapabilities
from .agent_executor import PrimeAgentExecutor

load_dotenv()

if __name__ == "__main__":
    base = os.getenv("AGENT_B_BASE", "http://127.0.0.1:8020")

    prime_skill = AgentSkill(
        id="prime_check",
        name="Prime Checker",
        description="Determines if a number is prime.",
        tags=["math","prime"],
        examples=["is 17 prime?"],
        input_modes=["text"],
        output_modes=["text"],
    )

    public_card = AgentCard(
        name="Agent B - Prime",
        description="Prime checker agent",
        url=base + "/",
        version="1.0.0",
        capabilities=AgentCapabilities(streaming=True),
        default_input_modes=["text"],
        default_output_modes=["text"],
        skills=[prime_skill],
    )

    handler = DefaultRequestHandler(
        agent_executor=PrimeAgentExecutor(),
        task_store=InMemoryTaskStore(),
    )

    app = A2AStarletteApplication(
        agent_card=public_card,
        http_handler=handler,
    ).build()

    uvicorn.run(app, host="0.0.0.0", port=8020)
