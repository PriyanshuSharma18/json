import asyncio
import logging
import os
import sys
import threading
import time

from typing import Any

import httpx
import nest_asyncio
import uvicorn

from a2a.client import ClientConfig, ClientFactory, create_text_message_object
from a2a.server.apps import A2AStarletteApplication
from a2a.server.request_handlers import DefaultRequestHandler
from a2a.server.tasks import InMemoryTaskStore
from a2a.types import (
    AgentCapabilities,
    AgentCard,
    AgentSkill,
    TransportProtocol,
)
from a2a.utils.constants import AGENT_CARD_WELL_KNOWN_PATH
from dotenv import load_dotenv
from google.adk.a2a.executor.a2a_agent_executor import (
    A2aAgentExecutor,
    A2aAgentExecutorConfig,
)
from google.adk.agents import Agent, SequentialAgent
from google.adk.agents.remote_a2a_agent import RemoteA2aAgent
from google.adk.artifacts import InMemoryArtifactService
from google.adk.memory.in_memory_memory_service import InMemoryMemoryService
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.adk.tools import google_search
import click
from host_agent import host_agent
from agent_executor import HostAgentExecutor

# Load environment variables
load_dotenv(dotenv_path="../../.env")

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class MissingAPIKeyError(Exception):
    """Exception for missing API key."""


@click.command()
@click.option("--host", default="localhost")
@click.option("--port", default=8003)
def main(host, port):
    # Validate Azure OpenAI configuration
    if not os.getenv("AZURE_OPENAI_API_KEY"):
        raise MissingAPIKeyError("AZURE_OPENAI_API_KEY environment variable is required")
    
    logger.info("🚀 Starting Host Agent with A2A SDK...")

    # Host Agent card (metadata)
    host_agent_card = AgentCard(
        name='Email Host Agent',
        url=f'http://{host}:{port}',
        description='Orchestrates email writing and reviewing using specialized sub-agents',
        version='1.0',
        capabilities=AgentCapabilities(streaming=True),
        default_input_modes=['text/plain'],
        default_output_modes=['application/json'],
        preferred_transport=TransportProtocol.jsonrpc,
        skills=[
            AgentSkill(
                id='email_orchestration',
                name='Email Orchestration',
                description='Coordinates email writing and reviewing through sequential sub-agents',
                tags=['email', 'writing', 'reviewing', 'orchestration'],
                examples=[
                    'Write and review an email',
                    'Create a professional email draft',
                    'Generate and validate email content',
                ],
            )
        ],
    )

    request_handler = DefaultRequestHandler(
        agent_executor=HostAgentExecutor(
            agent=host_agent,
        ),
        task_store=InMemoryTaskStore(),
    )

    server = A2AStarletteApplication(
        agent_card=host_agent_card, http_handler=request_handler
    )

    logger.info(f"✅ Host Agent ready on http://{host}:{port}")
    uvicorn.run(server.build(), host=host, port=port)


if __name__ == "__main__":
    main()