import asyncio
import logging
import os
import sys
import threading
import time

from typing import Any

import httpx
import nest_asyncio
import uvicorn

from a2a.client import ClientConfig, ClientFactory, create_text_message_object
from a2a.server.apps import A2AStarletteApplication
from a2a.server.request_handlers import DefaultRequestHandler
from a2a.server.tasks import InMemoryTaskStore
from a2a.types import (
    AgentCapabilities,
    AgentCard,
    AgentSkill,
    TransportProtocol,
)
from a2a.utils.constants import AGENT_CARD_WELL_KNOWN_PATH
from dotenv import load_dotenv
from google.adk.a2a.executor.a2a_agent_executor import (
    A2aAgentExecutor,
    A2aAgentExecutorConfig,
)
from google.adk.agents import Agent, SequentialAgent
from google.adk.agents.remote_a2a_agent import RemoteA2aAgent
from google.adk.artifacts import InMemoryArtifactService
from google.adk.memory.in_memory_memory_service import InMemoryMemoryService
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.adk.tools import google_search
import click
from email_reviewer_agent import root_agent as email_reviewer_agent
from agent_executor import EmailReviewerAgentExecutor

# Load environment variables
load_dotenv(dotenv_path="../../.env")

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class MissingAPIKeyError(Exception):
    """Exception for missing API key."""


@click.command()
@click.option("--host", default="localhost")
@click.option("--port", default=8002)
def main(host, port):
    # Validate Azure OpenAI configuration
    if not os.getenv("AZURE_OPENAI_API_KEY"):
        raise MissingAPIKeyError("AZURE_OPENAI_API_KEY environment variable is required")
    
    logger.info("🚀 Starting Email Reviewer Agent with A2A SDK...")

    # Email Reviewer Agent card (metadata)
    agent_card = AgentCard(
        name='Email Reviewer Agent',
        description=email_reviewer_agent.description,
        url=f'http://{host}:{port}',
        version="1.0.0",
        defaultInputModes=["text", "text/plain"],
        defaultOutputModes=["text", "text/plain"],
        capabilities=AgentCapabilities(streaming=True),
        skills=[
            AgentSkill(
                id="professional_email_review",
                name="Professional Email Review and Analysis",
                description="Provides comprehensive review and feedback on email drafts including grammar, style, tone, and effectiveness analysis",
                tags=["email", "review", "analysis", "feedback", "editing", "azure-openai"],
                examples=[
                    "Review this business email for grammar and professionalism",
                    "Analyze the tone and effectiveness of this client communication",
                    "Check this email for clarity and completeness",
                    "Provide feedback on this formal email structure and style"
                ],
            )
        ],
    )

    request_handler = DefaultRequestHandler(
        agent_executor=EmailReviewerAgentExecutor(
            agent=email_reviewer_agent,
        ),
        task_store=InMemoryTaskStore(),
    )

    server = A2AStarletteApplication(
        agent_card=agent_card, http_handler=request_handler
    )

    logger.info(f"✅ Email Reviewer Agent ready on http://{host}:{port}")
    uvicorn.run(server.build(), host=host, port=port)


if __name__ == "__main__":
    main()