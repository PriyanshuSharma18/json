import asyncio
import logging
import os
import sys
from typing import Any, Optional

import httpx
import nest_asyncio
import uvicorn

from a2a.client import ClientConfig, ClientFactory, create_text_message_object
from a2a.server.apps import A2AStarletteApplication
from a2a.server.request_handlers import DefaultRequestHandler
from a2a.server.tasks import InMemoryTaskStore
from a2a.types import (
    AgentCapabilities,
    AgentCard,
    AgentSkill,
    TransportProtocol,
)
from a2a.utils.constants import AGENT_CARD_WELL_KNOWN_PATH
from dotenv import load_dotenv
from google.adk.a2a.executor.a2a_agent_executor import (
    A2aAgentExecutor,
    A2aAgentExecutorConfig,
)
from google.adk.agents import Agent, SequentialAgent
from google.adk.agents.remote_a2a_agent import RemoteA2aAgent
from google.adk.artifacts import InMemoryArtifactService
from google.adk.memory.in_memory_memory_service import InMemoryMemoryService
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService

# Load environment variables
load_dotenv()

# Configure logging with proper format
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Enable nested async loops for development
nest_asyncio.apply()

# Configuration constants - consistent port usage
HOST_AGENT_PORT = 10023
HOST_AGENT_URL = f"http://localhost:{HOST_AGENT_PORT}"
EMAIL_WRITER_URL = "http://localhost:8001"
EMAIL_REVIEWER_URL = "http://localhost:8002"

# Timeout configurations
DISCOVERY_TIMEOUT = 30.0
SERVER_STARTUP_WAIT = 5.0
CONNECTION_TEST_TIMEOUT = 10.0

async def get_agent_card(url: str) -> Optional[AgentCard]:
    """Fetch agent card from remote agent with proper error handling."""
    try:
        timeout_config = httpx.Timeout(
            timeout=DISCOVERY_TIMEOUT,
            connect=10.0,
            read=DISCOVERY_TIMEOUT,
            write=10.0
        )
        
        async with httpx.AsyncClient(timeout=timeout_config) as client:
            logger.info(f"Fetching agent card from {url}")
            response = await client.get(f"{url}/.well-known/agent-card.json")
            response.raise_for_status()
            
            card_data = response.json()
            logger.info(f"Successfully retrieved agent card: {card_data.get('name', 'Unknown')}")
            return AgentCard(**card_data)
            
    except httpx.TimeoutException:
        logger.error(f"Timeout while fetching agent card from {url}")
        return None
    except httpx.HTTPStatusError as e:
        logger.error(f"HTTP error {e.response.status_code} while fetching agent card from {url}")
        return None
    except Exception as e:
        logger.error(f"Failed to fetch agent card from {url}: {str(e)}")
        return None

async def create_remote_agents():
    """Create remote A2A agents with proper agent cards and error handling."""
    print("🔍 Discovering remote agents...")
    
    # Discover Email Writer Agent
    writer_card = await get_agent_card(EMAIL_WRITER_URL)
    if not writer_card:
        raise RuntimeError(f"Failed to discover Email Writer Agent at {EMAIL_WRITER_URL}")
    
    email_writer_agent = RemoteA2aAgent(
        name="email_writer",
        agent_card=writer_card,
        url=EMAIL_WRITER_URL,
        description="Remote Email Writer Agent that creates professional emails using Azure OpenAI"
    )
    print(f"✅ Connected to Email Writer: {writer_card.name}")
    
    # Discover Email Reviewer Agent
    reviewer_card = await get_agent_card(EMAIL_REVIEWER_URL)
    if not reviewer_card:
        raise RuntimeError(f"Failed to discover Email Reviewer Agent at {EMAIL_REVIEWER_URL}")
    
    email_reviewer_agent = RemoteA2aAgent(
        name="email_reviewer",
        agent_card=reviewer_card,
        url=EMAIL_REVIEWER_URL,
        description="Remote Email Reviewer Agent that reviews and improves emails using Azure OpenAI"
    )
    print(f"✅ Connected to Email Reviewer: {reviewer_card.name}")
    
    return email_writer_agent, email_reviewer_agent

# Host Agent Card Configuration with Azure OpenAI integration details
host_agent_card = AgentCard(
    name='Email Orchestration Host Agent',
    url=HOST_AGENT_URL,
    description='Orchestrates email writing and review workflow using specialized A2A agents with Azure OpenAI integration',
    version='1.0.0',
    capabilities=AgentCapabilities(streaming=True),
    default_input_modes=['text/plain'],
    default_output_modes=['application/json', 'text/plain'],
    preferred_transport=TransportProtocol.jsonrpc,
    skills=[
        AgentSkill(
            id='email_workflow_orchestration',
            name='Email Workflow Orchestration',
            description='Coordinates complete email writing and review process using specialized A2A agents powered by Azure OpenAI',
            tags=['email', 'orchestration', 'workflow', 'a2a', 'azure-openai', 'professional-communication'],
            examples=[
                'Write and review an email to my manager about taking leave for my sister\'s wedding',
                'Create a professional meeting request email for next Tuesday',
                'Draft an apology email to a client for delayed shipment and get it reviewed',
                'Help me compose a follow-up email after a job interview',
                'Generate a thank you email to team members after project completion',
            ],
        )
    ],
)

async def run_host_agent_server():
    """Run the host agent server with proper error handling and logging."""
    try:
        print("🚀 Starting Email Orchestration Host Agent Server...")
        print(f"🌐 Server will run on {HOST_AGENT_URL}")
        
        # Create remote agents with proper agent cards
        email_writer_agent, email_reviewer_agent = await create_remote_agents()
        
        # Create the Host ADK Agent (Sequential workflow: Write -> Review)
        host_agent = SequentialAgent(
            name='email_orchestration_host',
            sub_agents=[email_writer_agent, email_reviewer_agent],
        )
        logger.info("Created sequential agent with email writer and reviewer")
        
        # Create task store and services
        task_store = InMemoryTaskStore()
        artifact_service = InMemoryArtifactService()
        memory_service = InMemoryMemoryService()
        session_service = InMemorySessionService()
        logger.info("Initialized all services (task store, artifact, memory, session)")
        
        # Create A2A Agent Executor configuration
        executor_config = A2aAgentExecutorConfig(
            agent_card=host_agent_card,
            task_store=task_store,
            artifact_service=artifact_service,
            memory_service=memory_service,
            session_service=session_service,
        )
        
        # Create A2A Agent Executor
        executor = A2aAgentExecutor(
            agent=host_agent,
            config=executor_config,
        )
        logger.info("Created A2A Agent Executor")
        
        # Create request handler
        request_handler = DefaultRequestHandler(
            agent_card=host_agent_card,
            agent_executor=executor,
            task_store=task_store,
        )
        
        # Create A2A Starlette application
        app = A2AStarletteApplication(
            agent_card=host_agent_card,
            request_handler=request_handler,
        )
        logger.info("Created A2A Starlette application")
        
        print(f"✅ Host Agent Server configured successfully")
        print(f"📋 Agent Card: {host_agent_card.name}")
        print(f"🔗 Skills: {[skill.name for skill in host_agent_card.skills]}")
        print(f"🎯 Connected Agents: Email Writer + Email Reviewer")
        print(f"🤖 Ready to orchestrate email workflows with Azure OpenAI!")
        print(f"🚀 Starting server on {HOST_AGENT_URL}...")
        
        # Configure and run the server
        config = uvicorn.Config(
            app=app,
            host="0.0.0.0",
            port=HOST_AGENT_PORT,
            log_level="info",
            access_log=True
        )
        server = uvicorn.Server(config)
        await server.serve()
        
    except RuntimeError as e:
        logger.error(f"❌ Runtime error starting host agent server: {e}")
        print(f"❌ Failed to start server: {e}")
        print("\n💡 Make sure both Email Writer (port 8001) and Email Reviewer (port 8002) agents are running!")
        raise
    except Exception as e:
        logger.error(f"❌ Unexpected error starting host agent server: {e}")
        print(f"❌ Server startup failed: {e}")
        raise

def run_server_sync():
    """Synchronous wrapper to run the async server."""
    try:
        asyncio.run(run_host_agent_server())
    except KeyboardInterrupt:
        print("\n👋 Host Agent Server stopped by user")
    except Exception as e:
        print(f"❌ Server error: {e}")
        sys.exit(1)

async def test_host_agent():
    """Test the host agent functionality with proper timing."""
    try:
        print(f"\n🧪 Testing Host Agent Functionality on {HOST_AGENT_URL}...")
        
        # Wait for server to be ready
        print(f"⏳ Waiting {SERVER_STARTUP_WAIT} seconds for server startup...")
        await asyncio.sleep(SERVER_STARTUP_WAIT)
        
        # Test connection to host agent
        timeout_config = httpx.Timeout(
            timeout=CONNECTION_TEST_TIMEOUT,
            connect=5.0,
            read=CONNECTION_TEST_TIMEOUT,
            write=5.0
        )
        
        async with httpx.AsyncClient(timeout=timeout_config) as client:
            try:
                print(f"🔍 Testing connection to {HOST_AGENT_URL}/.well-known/agent-card.json")
                response = await client.get(f"{HOST_AGENT_URL}/.well-known/agent-card.json")
                
                if response.status_code == 200:
                    card_data = response.json()
                    print(f"✅ Host Agent is running: {card_data['name']}")
                    print(f"📋 Version: {card_data.get('version', 'Unknown')}")
                    print(f"🔗 Skills: {len(card_data.get('skills', []))} available")
                    return True
                else:
                    print(f"❌ Host Agent not responding properly: {response.status_code}")
                    return False
                    
            except httpx.TimeoutException:
                print(f"❌ Timeout connecting to Host Agent at {HOST_AGENT_URL}")
                return False
            except Exception as e:
                print(f"❌ Cannot connect to Host Agent at {HOST_AGENT_URL}: {e}")
                return False
                
    except Exception as e:
        logger.error(f"❌ Host Agent test failed: {e}")
        return False

async def test_remote_connections():
    """Test connections to remote agents with detailed feedback."""
    try:
        print("\n🔍 Testing Remote Agent Connections...")
        
        agents_to_test = [
            ("Email Writer Agent", EMAIL_WRITER_URL),
            ("Email Reviewer Agent", EMAIL_REVIEWER_URL)
        ]
        
        timeout_config = httpx.Timeout(
            timeout=CONNECTION_TEST_TIMEOUT,
            connect=5.0,
            read=CONNECTION_TEST_TIMEOUT,
            write=5.0
        )
        
        async with httpx.AsyncClient(timeout=timeout_config) as client:
            all_connected = True
            
            for name, url in agents_to_test:
                try:
                    print(f"🔍 Testing {name} at {url}...")
                    response = await client.get(f"{url}/.well-known/agent-card.json")
                    
                    if response.status_code == 200:
                        card_data = response.json()
                        print(f"✅ {name} is available: {card_data['name']}")
                        print(f"   📋 Description: {card_data.get('description', 'No description')}")
                    else:
                        print(f"❌ {name} not responding: HTTP {response.status_code}")
                        all_connected = False
                        
                except httpx.TimeoutException:
                    print(f"❌ {name} connection timeout at {url}")
                    all_connected = False
                except Exception as e:
                    print(f"❌ Cannot connect to {name}: {e}")
                    all_connected = False
        
        return all_connected
        
    except Exception as e:
        logger.error(f"❌ Remote connection test failed: {e}")
        return False

async def comprehensive_health_check():
    """Run comprehensive health check of the entire A2A system."""
    print("🏥 Running Comprehensive A2A System Health Check...")
    print("=" * 60)
    
    # Test remote agents first
    remote_ok = await test_remote_connections()
    if not remote_ok:
        print("❌ Remote agents health check failed")
        return False
    
    print("\n" + "=" * 60)
    
    # Test host agent
    host_ok = await test_host_agent()
    if not host_ok:
        print("❌ Host agent health check failed")
        return False
    
    print("\n" + "=" * 60)
    print("✅ All A2A system components are healthy and ready!")
    return True

if __name__ == "__main__":
    print("🎯 Email Orchestration Host Agent with Azure OpenAI")
    print("=" * 60)
    print(f"🌐 Host Agent URL: {HOST_AGENT_URL}")
    print(f"📧 Email Writer URL: {EMAIL_WRITER_URL}")
    print(f"🔍 Email Reviewer URL: {EMAIL_REVIEWER_URL}")
    
    if len(sys.argv) > 1:
        command = sys.argv[1]
        
        if command == "--test":
            # Comprehensive test mode
            result = asyncio.run(comprehensive_health_check())
            sys.exit(0 if result else 1)
            
        elif command == "--check":
            # Check remote connections only
            result = asyncio.run(test_remote_connections())
            sys.exit(0 if result else 1)
            
        elif command == "--host-test":
            # Test host agent only
            result = asyncio.run(test_host_agent())
            sys.exit(0 if result else 1)
            
        else:
            print(f"❌ Unknown command: {command}")
            print("Available commands: --test, --check, --host-test")
            sys.exit(1)
    else:
        # Run the server
        print("🚀 Starting Host Agent Server...")
        print("📋 Prerequisites:")
        print("   • Email Writer Agent must be running on port 8001")
        print("   • Email Reviewer Agent must be running on port 8002")
        print("   • Azure OpenAI credentials must be configured in .env")
        print("\n💡 Press Ctrl+C to stop the server")
        print("=" * 60)
        
        run_server_sync()