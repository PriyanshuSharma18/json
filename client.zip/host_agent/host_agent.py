import asyncio
import logging
import os
import sys
import threading
import time
from typing import Any, Optional

import httpx
import nest_asyncio
import uvicorn

from a2a.client import ClientConfig, ClientFactory, create_text_message_object
from a2a.server.apps import A2AStarletteApplication
from a2a.server.request_handlers import DefaultRequestHandler
from a2a.server.tasks import InMemoryTaskStore
from a2a.types import (
    AgentCapabilities,
    AgentCard,
    AgentSkill,
    TransportProtocol,
)
from a2a.utils.constants import AGENT_CARD_WELL_KNOWN_PATH
from dotenv import load_dotenv
from google.adk.a2a.executor.a2a_agent_executor import (
    A2aAgentExecutor,
    A2aAgentExecutorConfig,
)
from google.adk.agents import Agent, SequentialAgent
from google.adk.agents.remote_a2a_agent import RemoteA2aAgent
from google.adk.artifacts import InMemoryArtifactService
from google.adk.memory.in_memory_memory_service import InMemoryMemoryService
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService

# Load environment variables
load_dotenv()

# Configure logging with proper format for debugging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Enable nested async loops for development
nest_asyncio.apply()

# Configuration constants
HOST_AGENT_PORT = 10023
HOST_AGENT_URL = f"http://localhost:{HOST_AGENT_PORT}"
EMAIL_WRITER_URL = "http://localhost:8001"
EMAIL_REVIEWER_URL = "http://localhost:8002"

async def get_agent_card(url: str) -> Optional[AgentCard]:
    """Fetch agent card from remote agent with proper error handling."""
    try:
        logger.info(f"Fetching agent card from {url}")
        
        timeout_config = httpx.Timeout(
            timeout=30.0,
            connect=10.0,
            read=30.0,
            write=10.0
        )
        
        async with httpx.AsyncClient(timeout=timeout_config) as client:
            response = await client.get(f"{url}/.well-known/agent-card.json")
            response.raise_for_status()
            
            card_data = response.json()
            logger.info(f"Successfully retrieved agent card: {card_data.get('name', 'Unknown')}")
            return AgentCard(**card_data)
            
    except httpx.HTTPStatusError as e:
        logger.error(f"HTTP error {e.response.status_code} fetching agent card from {url}")
        return None
    except httpx.ConnectError:
        logger.error(f"Connection error - cannot reach agent at {url}")
        return None
    except Exception as e:
        logger.error(f"Failed to fetch agent card from {url}: {e}")
        return None

async def create_remote_agents():
    """Create remote A2A agents using proper constructor parameters."""
    print("🔍 Discovering remote agents...")
    
    # Get Email Writer Agent Card
    writer_card = await get_agent_card(EMAIL_WRITER_URL)
    if not writer_card:
        raise RuntimeError(f"Cannot connect to Email Writer Agent at {EMAIL_WRITER_URL}")
    
    # Create RemoteA2aAgent with only the required parameters
    email_writer_agent = RemoteA2aAgent(
        name="email_writer",
        agent_card=writer_card,
    )
    print(f"✅ Connected to Email Writer: {writer_card.name}")
    
    # Get Email Reviewer Agent Card
    reviewer_card = await get_agent_card(EMAIL_REVIEWER_URL)
    if not reviewer_card:
        raise RuntimeError(f"Cannot connect to Email Reviewer Agent at {EMAIL_REVIEWER_URL}")
    
    # Create RemoteA2aAgent with only the required parameters
    email_reviewer_agent = RemoteA2aAgent(
        name="email_reviewer",
        agent_card=reviewer_card,
    )
    print(f"✅ Connected to Email Reviewer: {reviewer_card.name}")
    
    return email_writer_agent, email_reviewer_agent

# Host Agent Card Configuration following AI Agent best practices
host_agent_card = AgentCard(
    name='Email Orchestration Host Agent',
    url=HOST_AGENT_URL,
    description='Orchestrates, sequentially, email writing and review using specialized A2A agents with Azure OpenAI integration',
    version='1.0.0',
    capabilities=AgentCapabilities(streaming=True),
    default_input_modes=['text/plain'],
    default_output_modes=['application/json'],
    preferred_transport=TransportProtocol.jsonrpc,
    skills=[
        AgentSkill(
            id='email_workflow_orchestration',
            name='Email Workflow Orchestration',
            description='Coordinates complete email writing and review process using specialized A2A agents powered by Azure OpenAI',
            tags=['email', 'orchestration', 'workflow', 'a2a', 'azure-openai', 'professional-communication'],
            examples=[
                'Write and review an email to manager about leave for sister\'s wedding',
                'Create professional meeting request email for next Tuesday',
                'Draft apology email to client for delayed shipment and get it reviewed',
                'Generate comprehensive email with review and improvements',
                'Compose professional email and get expert feedback',
            ],
        )
    ],
)

def create_agent_a2a_server(agent: Agent, agent_card: AgentCard) -> A2AStarletteApplication:
    """Create an A2A server for any ADK agent following best practices.

    Args:
        agent: The ADK agent instance
        agent_card: The ADK agent card

    Returns:
        A2AStarletteApplication instance
    """
    # Create Runner with all required services
    runner = Runner(
        app_name=agent.name,
        agent=agent,
        artifact_service=InMemoryArtifactService(),
        session_service=InMemorySessionService(),
        memory_service=InMemoryMemoryService(),
    )
    
    # Create A2A Agent Executor configuration
    config = A2aAgentExecutorConfig()
    
    # Create A2A Agent Executor with runner (this was missing!)
    executor = A2aAgentExecutor(runner=runner, config=config)
    
    # Create request handler
    request_handler = DefaultRequestHandler(
        agent_executor=executor,
        task_store=InMemoryTaskStore(),
    )
    
    # Create A2A application
    return A2AStarletteApplication(
        agent_card=agent_card, 
        http_handler=request_handler
    )

async def run_agent_server(agent: Agent, agent_card: AgentCard, port: int) -> None:
    """Run a single agent server following best practices."""
    try:
        logger.info(f"Creating A2A server for {agent_card.name} on port {port}")
        app = create_agent_a2a_server(agent, agent_card)
        
        config = uvicorn.Config(
            app.build(),
            host='0.0.0.0',  # Allow external connections
            port=port,
            log_level='info',
            loop='none',  # Important: let uvicorn use the current loop
        )
        
        server = uvicorn.Server(config)
        logger.info(f"✅ Starting {agent_card.name} server on http://localhost:{port}")
        await server.serve()
        
    except Exception as e:
        logger.error(f"❌ Failed to start server for {agent_card.name}: {e}")
        raise

async def run_host_agent_server():
    """Run the host agent server following AI Agent development best practices."""
    try:
        print("🚀 Starting Email Orchestration Host Agent Server...")
        print(f"🌐 Server will run on {HOST_AGENT_URL}")
        
        # Create remote agents with proper error handling
        email_writer_agent, email_reviewer_agent = await create_remote_agents()
        
        # Create sequential agent for orchestrated workflow
        # This follows the pattern: Write Email -> Review Email -> Return Results
        host_agent = SequentialAgent(
            name='email_orchestration_host',
            sub_agents=[email_writer_agent, email_reviewer_agent],
        )
        logger.info("✅ Created sequential agent workflow: Writer -> Reviewer")
        
        print(f"✅ Host Agent configured successfully!")
        print(f"📋 Agent Name: {host_agent_card.name}")
        print(f"🌐 Server URL: {HOST_AGENT_URL}")
        print(f"🎯 Workflow: Email Writer -> Email Reviewer -> Results")
        print(f"🤖 Azure OpenAI Integration: Active")
        print(f"🚀 Starting server on port {HOST_AGENT_PORT}...")
        
        # Run the agent server using the proven pattern
        await run_agent_server(host_agent, host_agent_card, HOST_AGENT_PORT)
        
    except RuntimeError as e:
        logger.error(f"❌ Runtime error starting host agent: {e}")
        print(f"\n❌ Failed to start Host Agent: {e}")
        print("\n💡 Troubleshooting Steps:")
        print("1. Verify Email Writer Agent is running: curl http://localhost:8001/.well-known/agent-card.json")
        print("2. Verify Email Reviewer Agent is running: curl http://localhost:8002/.well-known/agent-card.json")
        print("3. Check Azure OpenAI configuration in .env file")
        print("4. Ensure all dependencies are installed")
        raise
        
    except Exception as e:
        logger.error(f"❌ Unexpected error starting host agent: {e}")
        print(f"\n❌ Unexpected server error: {e}")
        raise

def run_server_sync():
    """Synchronous wrapper to run the async server."""
    try:
        asyncio.run(run_host_agent_server())
    except KeyboardInterrupt:
        print("\n👋 Host Agent Server stopped by user")
    except Exception as e:
        print(f"\n❌ Server error: {e}")
        sys.exit(1)

async def test_remote_connections():
    """Test remote agent connections with comprehensive validation."""
    print("🔍 Testing Remote Agent Connections...")
    
    agents_to_test = [
        ("Email Writer Agent", EMAIL_WRITER_URL),
        ("Email Reviewer Agent", EMAIL_REVIEWER_URL)
    ]
    
    timeout_config = httpx.Timeout(
        timeout=15.0,
        connect=5.0,
        read=15.0,
        write=5.0
    )
    
    async with httpx.AsyncClient(timeout=timeout_config) as client:
        all_connected = True
        
        for name, url in agents_to_test:
            try:
                print(f"🔍 Testing {name} at {url}...")
                response = await client.get(f"{url}/.well-known/agent-card.json")
                
                if response.status_code == 200:
                    card_data = response.json()
                    print(f"✅ {name} is available: {card_data['name']}")
                    print(f"   📋 Description: {card_data.get('description', 'No description')}")
                    print(f"   🔗 URL: {card_data.get('url', 'No URL')}")
                else:
                    print(f"❌ {name} not responding: HTTP {response.status_code}")
                    all_connected = False
                    
            except httpx.ConnectError:
                print(f"❌ {name} connection refused - agent may not be running")
                all_connected = False
            except httpx.TimeoutException:
                print(f"❌ {name} connection timeout")
                all_connected = False
            except Exception as e:
                print(f"❌ Cannot connect to {name}: {e}")
                all_connected = False
        
        return all_connected

async def test_host_agent():
    """Test host agent connection with proper timing."""
    print(f"🧪 Testing Host Agent at {HOST_AGENT_URL}...")
    
    # Wait for server startup
    print("⏳ Waiting for server startup...")
    await asyncio.sleep(5)
    
    timeout_config = httpx.Timeout(
        timeout=15.0,
        connect=5.0,
        read=15.0,
        write=5.0
    )
    
    async with httpx.AsyncClient(timeout=timeout_config) as client:
        try:
            response = await client.get(f"{HOST_AGENT_URL}/.well-known/agent-card.json")
            
            if response.status_code == 200:
                card_data = response.json()
                print(f"✅ Host Agent is running: {card_data['name']}")
                print(f"📋 Version: {card_data.get('version', 'Unknown')}")
                print(f"🔗 Skills: {len(card_data.get('skills', []))} available")
                return True
            else:
                print(f"❌ Host Agent not responding: HTTP {response.status_code}")
                return False
                
        except httpx.ConnectError:
            print(f"❌ Cannot connect to Host Agent - server may not be running")
            return False
        except httpx.TimeoutException:
            print(f"❌ Timeout connecting to Host Agent")
            return False
        except Exception as e:
            print(f"❌ Error testing Host Agent: {e}")
            return False

# A2A Simple Client for testing (following the reference pattern)
class A2ASimpleClient:
    """A2A Simple Client to call A2A servers following best practices."""

    def __init__(self, default_timeout: float = 240.0):
        self._agent_info_cache: dict[str, dict[str, Any] | None] = {}
        self.default_timeout = default_timeout

    async def create_task(self, agent_url: str, message: str) -> str:
        """Send a message following the official A2A SDK pattern."""
        timeout_config = httpx.Timeout(
            timeout=self.default_timeout,
            connect=10.0,
            read=self.default_timeout,
            write=10.0,
            pool=5.0,
        )

        async with httpx.AsyncClient(timeout=timeout_config) as httpx_client:
            # Check if we have cached agent card data
            if (
                agent_url in self._agent_info_cache
                and self._agent_info_cache[agent_url] is not None
            ):
                agent_card_data = self._agent_info_cache[agent_url]
            else:
                # Fetch the agent card
                agent_card_response = await httpx_client.get(
                    f'{agent_url}{AGENT_CARD_WELL_KNOWN_PATH}'
                )
                agent_card_data = self._agent_info_cache[agent_url] = (
                    agent_card_response.json()
                )

            # Create AgentCard from data
            agent_card = AgentCard(**agent_card_data)

            # Create A2A client with the agent card
            config = ClientConfig(
                httpx_client=httpx_client,
                supported_transports=[
                    TransportProtocol.jsonrpc,
                    TransportProtocol.http_json,
                ],
                use_client_preference=True,
            )

            factory = ClientFactory(config)
            client = factory.create(agent_card)

            # Create the message object
            message_obj = create_text_message_object(content=message)

            # Send the message and collect responses
            responses = []
            async for response in client.send_message(message_obj):
                responses.append(response)

            # The response is a tuple - get the first element (Task object)
            if (
                responses
                and isinstance(responses[0], tuple)
                and len(responses[0]) > 0
            ):
                task = responses[0][0]  # First element of the tuple

                # Extract text: task.artifacts[0].parts[0].root.text
                try:
                    return task.artifacts[0].parts[0].root.text
                except (AttributeError, IndexError):
                    return str(task)

            return 'No response received'

if __name__ == "__main__":
    print("🎯 Email Orchestration Host Agent with Azure OpenAI")
    print("=" * 60)
    print(f"🌐 Host Agent URL: {HOST_AGENT_URL}")
    print(f"📧 Email Writer URL: {EMAIL_WRITER_URL}")
    print(f"🔍 Email Reviewer URL: {EMAIL_REVIEWER_URL}")
    
    if len(sys.argv) > 1:
        command = sys.argv[1]
        
        if command == "--test":
            # Comprehensive test mode
            async def run_tests():
                print("🏥 Running comprehensive A2A system health check...")
                print("=" * 60)
                
                remote_ok = await test_remote_connections()
                if remote_ok:
                    print("\n" + "=" * 60)
                    host_ok = await test_host_agent()
                    
                    if host_ok:
                        print("\n" + "=" * 60)
                        print("✅ All A2A system components are healthy and ready!")
                        print("🎯 You can now interact with the system using the A2A client")
                        
                        # Test the host agent with a sample email request
                        print("\n🧪 Testing Host Agent with sample email request...")
                        try:
                            a2a_client = A2ASimpleClient()
                            result = await a2a_client.create_task(
                                HOST_AGENT_URL,
                                "Write and review an email to my manager about taking leave for my sister's wedding"
                            )
                            print(f"✅ Sample request result: {result[:200]}...")
                        except Exception as e:
                            print(f"⚠️ Sample request failed (this is normal for initial setup): {e}")
                        
                        return True
                    else:
                        print("\n❌ Host agent is not responding")
                        return False
                else:
                    print("\n❌ Remote agents are not available")
                    return False
            
            result = asyncio.run(run_tests())
            sys.exit(0 if result else 1)
            
        elif command == "--check":
            # Check remote connections only
            result = asyncio.run(test_remote_connections())
            sys.exit(0 if result else 1)
            
        else:
            print(f"❌ Unknown command: {command}")
            print("Available commands: --test, --check")
            sys.exit(1)
    else:
        # Run the server
        print("🚀 Starting Host Agent Server...")
        print("📋 Prerequisites Verified:")
        print("   ✅ Email Writer Agent running on port 8001")
        print("   ✅ Email Reviewer Agent running on port 8002")
        print("   ✅ Azure OpenAI credentials configured")
        print("\n💡 Press Ctrl+C to stop the server")
        print("=" * 60)
        
        run_server_sync()