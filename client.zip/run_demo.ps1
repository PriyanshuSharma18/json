# A2A Demo PowerShell Script
# This script demonstrates Agent-to-Agent communication for Windows users

Write-Host "🎭 A2A Demo: Agent-to-Agent Communication" -ForegroundColor Magenta
Write-Host "=" * 50 -ForegroundColor Cyan

# Check if Python is installed
try {
    $pythonVersion = python --version 2>&1
    Write-Host "✓ Python found: $pythonVersion" -ForegroundColor Green
} catch {
    Write-Host "✗ Python not found. Please install Python 3.8+ and add it to PATH." -ForegroundColor Red
    exit 1
}

# Check if pip is available
try {
    pip --version | Out-Null
    Write-Host "✓ pip is available" -ForegroundColor Green
} catch {
    Write-Host "✗ pip not found. Please ensure pip is installed." -ForegroundColor Red
    exit 1
}

Write-Host "`n📦 Installing dependencies..." -ForegroundColor Cyan
try {
    pip install -r requirements.txt
    Write-Host "✓ Dependencies installed successfully" -ForegroundColor Green
} catch {
    Write-Host "✗ Failed to install dependencies. Please check requirements.txt" -ForegroundColor Red
    exit 1
}

Write-Host "`n🔧 Checking environment configuration..." -ForegroundColor Cyan
if (-not (Test-Path ".env")) {
    Write-Host "✗ .env file not found. Please create .env file with your Azure OpenAI configuration." -ForegroundColor Red
    exit 1
}
Write-Host "✓ Environment file found" -ForegroundColor Green

Write-Host "`n🚀 Starting A2A Demo..." -ForegroundColor Cyan
Write-Host "This will start both agents and run the demo client." -ForegroundColor Yellow

# Run the demo
try {
    python run_demo.py
    Write-Host "`n🎉 A2A Demo completed!" -ForegroundColor Green
} catch {
    Write-Host "`n❌ Demo failed. Check the output above for details." -ForegroundColor Red
    exit 1
}

Write-Host "`nPress any key to continue..." -ForegroundColor Yellow
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")