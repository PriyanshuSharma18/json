#!/usr/bin/env python3
"""
A2A Demo Orchestrator
Manages the startup and demonstration of Agent-to-Agent communication.
"""

import asyncio
import subprocess
import time
import os
import sys
from pathlib import Path
import httpx
from colorama import init, Fore, Style
from dotenv import load_dotenv

init()

# Load environment variables from .env file
load_dotenv()

class A2ADemoOrchestrator:
    """Orchestrates the A2A demo by managing agent startup and execution."""
    
    def __init__(self):
        self.base_path = Path(__file__).parent
        self.processes = []
        self.echo_agent_process = None
        self.reviewer_agent_process = None
    
    def check_dependencies(self):
        """Check if required dependencies are installed."""
        print(f"{Fore.CYAN}📋 Checking dependencies...{Style.RESET_ALL}")
        
        try:
            import a2a
            import openai
            import uvicorn
            import click
            import httpx
            import dotenv
            print(f"{Fore.GREEN}✓ All required packages are installed{Style.RESET_ALL}")
            return True
        except ImportError as e:
            print(f"{Fore.RED}✗ Missing required package: {str(e)}{Style.RESET_ALL}")
            print(f"{Fore.YELLOW}Please install dependencies: pip install -r requirements.txt{Style.RESET_ALL}")
            return False
    
    def check_environment(self):
        """Check if environment variables are properly set."""
        print(f"{Fore.CYAN}🔧 Checking environment configuration...{Style.RESET_ALL}")
        
        required_vars = [
            'AZURE_OPENAI_API_KEY',
            'AZURE_OPENAI_ENDPOINT', 
            'AZURE_OPENAI_DEPLOYMENT_NAME'
        ]
        
        missing_vars = []
        for var in required_vars:
            if not os.getenv(var):
                missing_vars.append(var)
        
        if missing_vars:
            print(f"{Fore.RED}✗ Missing environment variables: {', '.join(missing_vars)}{Style.RESET_ALL}")
            print(f"{Fore.YELLOW}Please check your .env file{Style.RESET_ALL}")
            return False
        
        print(f"{Fore.GREEN}✓ Environment configuration is valid{Style.RESET_ALL}")
        return True
    
    async def check_agent_health(self, url: str, agent_name: str, max_retries: int = 10):
        """Check if an agent is responding to health checks."""
        print(f"{Fore.CYAN}🔍 Waiting for {agent_name} to start at {url}...{Style.RESET_ALL}")
        
        async with httpx.AsyncClient() as client:
            for attempt in range(max_retries):
                try:
                    response = await client.get(f"{url}/.well-known/agent-card.json", timeout=5.0)
                    if response.status_code == 200:
                        print(f"{Fore.GREEN}✓ {agent_name} is ready!{Style.RESET_ALL}")
                        return True
                except Exception:
                    pass
                
                print(f"  Attempt {attempt + 1}/{max_retries}...")
                await asyncio.sleep(2)
        
        print(f"{Fore.RED}✗ {agent_name} failed to start{Style.RESET_ALL}")
        return False
    
    def start_echo_agent(self):
        """Start the Echo Agent in a separate process."""
        print(f"{Fore.CYAN}🚀 Starting Echo Agent...{Style.RESET_ALL}")
        
        echo_agent_path = self.base_path / "agents" / "echo_agent"
        
        # Change to the echo agent directory and run it
        self.echo_agent_process = subprocess.Popen(
            [sys.executable, "__main__.py", "--host", "localhost", "--port", "8001"],
            cwd=echo_agent_path,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        self.processes.append(self.echo_agent_process)
        return self.echo_agent_process
    
    def start_reviewer_agent(self):
        """Start the Reviewer Agent in a separate process."""
        print(f"{Fore.CYAN}🚀 Starting Reviewer Agent...{Style.RESET_ALL}")
        
        reviewer_agent_path = self.base_path / "agents" / "reviewer_agent"
        
        # Change to the reviewer agent directory and run it
        self.reviewer_agent_process = subprocess.Popen(
            [sys.executable, "__main__.py", "--host", "localhost", "--port", "8002"],
            cwd=reviewer_agent_path,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        self.processes.append(self.reviewer_agent_process)
        return self.reviewer_agent_process
    
    async def start_agents(self):
        """Start both agents and wait for them to be ready."""
        print(f"\n{Fore.MAGENTA}🎭 A2A Demo: Starting Agents{Style.RESET_ALL}")
        print("=" * 50)
        
        # Start agents
        self.start_echo_agent()
        self.start_reviewer_agent()
        
        # Wait for agents to be ready
        echo_ready = await self.check_agent_health("http://localhost:8001", "Echo Agent")
        reviewer_ready = await self.check_agent_health("http://localhost:8002", "Reviewer Agent")
        
        if echo_ready and reviewer_ready:
            print(f"{Fore.GREEN}🎉 Both agents are ready!{Style.RESET_ALL}")
            return True
        else:
            print(f"{Fore.RED}❌ Failed to start agents{Style.RESET_ALL}")
            return False
    
    def run_demo_client(self):
        """Run the demo client."""
        print(f"\n{Fore.CYAN}🎬 Starting A2A Demo Client...{Style.RESET_ALL}")
        
        client_path = self.base_path / "client"
        
        # Run the demo client
        result = subprocess.run(
            [sys.executable, "demo_client.py", "--demo"],
            cwd=client_path,
            capture_output=False
        )
        
        return result.returncode == 0
    
    def cleanup(self):
        """Clean up all processes."""
        print(f"\n{Fore.YELLOW}🧹 Cleaning up processes...{Style.RESET_ALL}")
        
        for process in self.processes:
            if process and process.poll() is None:
                process.terminate()
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    process.kill()
        
        print(f"{Fore.GREEN}✓ Cleanup completed{Style.RESET_ALL}")
    
    def print_presentation_summary(self):
        """Print a summary for presentation purposes."""
        print(f"\n{Fore.MAGENTA}🎯 A2A Demo Summary for Presentation{Style.RESET_ALL}")
        print("=" * 60)
        print(f"{Fore.CYAN}What was demonstrated:{Style.RESET_ALL}")
        print("1. ✅ Two independent AI agents running on different ports")
        print("   - Echo Agent (localhost:8001): Enhances messages with AI commentary")
        print("   - Reviewer Agent (localhost:8002): Provides detailed text analysis")
        print("")
        print("2. ✅ Agent-to-Agent (A2A) Protocol Communication")
        print("   - Standardized JSON-RPC based messaging")
        print("   - Agent discovery via agent cards")
        print("   - Streaming capabilities")
        print("")
        print("3. ✅ Real-world Use Cases Demonstrated")
        print("   - Direct agent communication")
        print("   - Agent chaining (Echo → Reviewer)")
        print("   - Interactive multi-agent workflows")
        print("")
        print(f"{Fore.GREEN}4. ✅ Azure OpenAI Integration{Style.RESET_ALL}")
        print("   - Both agents powered by your Azure OpenAI deployment")
        print("   - Demonstrates enterprise-ready AI agent architecture")
        print("")
        print(f"{Fore.YELLOW}Key Benefits of A2A Protocol:{Style.RESET_ALL}")
        print("• 🔄 Interoperability between different agent implementations")
        print("• 📡 Standardized communication protocol")
        print("• 🎯 Specialized agents can focus on specific tasks")
        print("• ⚡ Scalable multi-agent architectures")
        print("• 🔌 Easy integration with existing systems")
    
    async def run_full_demo(self):
        """Run the complete demo sequence."""
        print(f"{Fore.MAGENTA}🎪 A2A Demo Orchestrator{Style.RESET_ALL}")
        print(f"{Fore.CYAN}Agent-to-Agent Communication Demonstration{Style.RESET_ALL}")
        print("=" * 60)
        
        try:
            # Pre-flight checks
            if not self.check_dependencies():
                return False
            
            if not self.check_environment():
                return False
            
            # Start agents
            if not await self.start_agents():
                return False
            
            # Wait a moment for everything to settle
            await asyncio.sleep(2)
            
            # Run the demo
            demo_success = self.run_demo_client()
            
            # Show summary
            self.print_presentation_summary()
            
            return demo_success
            
        except KeyboardInterrupt:
            print(f"\n{Fore.YELLOW}Demo interrupted by user{Style.RESET_ALL}")
            return False
        except Exception as e:
            print(f"\n{Fore.RED}Demo failed with error: {str(e)}{Style.RESET_ALL}")
            return False
        finally:
            self.cleanup()


async def main():
    """Main entry point for the demo orchestrator."""
    orchestrator = A2ADemoOrchestrator()
    success = await orchestrator.run_full_demo()
    
    if success:
        print(f"\n{Fore.GREEN}🎉 A2A Demo completed successfully!{Style.RESET_ALL}")
        return 0
    else:
        print(f"\n{Fore.RED}❌ A2A Demo failed{Style.RESET_ALL}")
        return 1


if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)