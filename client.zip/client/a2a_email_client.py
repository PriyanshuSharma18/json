import asyncio
import logging
from typing import Optional, Any

import click
import httpx
from colorama import init, Fore, Style
from dotenv import load_dotenv
from a2a.client import ClientConfig, ClientFactory, create_text_message_object
from a2a.types import AgentCard, TransportProtocol

# Initialize colorama for colored output
init()

# Load environment variables
load_dotenv(dotenv_path="../.env")

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

AGENT_CARD_WELL_KNOWN_PATH = "/.well-known/agent-card.json"


class A2AIntelligentClient:
    """Intelligent A2A Client that orchestrates email agents and handles general queries."""
    
    def __init__(self, default_timeout: float = 240.0):
        self.email_writer_url = "http://localhost:8001"
        self.email_reviewer_url = "http://localhost:8002"
        self.default_timeout = default_timeout
        self._agent_info_cache: dict[str, dict[str, Any] | None] = {}
        self.writer_card = None
        self.reviewer_card = None
    
    async def _get_agent_card(self, agent_url: str, httpx_client: httpx.AsyncClient) -> AgentCard:
        """Get agent card with caching."""
        if (
            agent_url in self._agent_info_cache
            and self._agent_info_cache[agent_url] is not None
        ):
            agent_card_data = self._agent_info_cache[agent_url]
        else:
            # Fetch the agent card
            agent_card_response = await httpx_client.get(
                f'{agent_url}{AGENT_CARD_WELL_KNOWN_PATH}'
            )
            agent_card_data = self._agent_info_cache[agent_url] = (
                agent_card_response.json()
            )
        
        return AgentCard(**agent_card_data)
    
    async def _send_message_to_agent(self, agent_url: str, message: str) -> str:
        """Send a message to an agent following the official A2A SDK pattern."""
        # Configure httpx client with timeout
        timeout_config = httpx.Timeout(
            timeout=self.default_timeout,
            connect=10.0,
            read=self.default_timeout,
            write=10.0,
            pool=5.0,
        )
        
        async with httpx.AsyncClient(timeout=timeout_config) as httpx_client:
            # Get agent card
            agent_card = await self._get_agent_card(agent_url, httpx_client)
            
            # Create A2A client with the agent card
            config = ClientConfig(
                httpx_client=httpx_client,
                supported_transports=[
                    TransportProtocol.jsonrpc,
                    TransportProtocol.http_json,
                ],
                use_client_preference=True,
            )
            
            factory = ClientFactory(config)
            client = factory.create(agent_card)
            
            # Create the message object
            message_obj = create_text_message_object(content=message)
            
            # Send the message and collect responses
            responses = []
            async for response in client.send_message(message_obj):
                responses.append(response)
            
            # The response is a tuple - get the first element (Task object)
            if (
                responses
                and isinstance(responses[0], tuple)
                and len(responses[0]) > 0
            ):
                task = responses[0][0]  # First element of the tuple
                
                # Extract text: task.artifacts[0].parts[0].root.text
                try:
                    return task.artifacts[0].parts[0].root.text
                except (AttributeError, IndexError):
                    return str(task)
            
            return 'No response received'
    
    async def initialize(self):
        """Initialize and discover agents."""
        try:
            print(f"{Fore.CYAN}🔍 Discovering A2A agents...{Style.RESET_ALL}")
            
            # Configure httpx client for discovery
            timeout_config = httpx.Timeout(
                timeout=30.0,
                connect=10.0,
                read=30.0,
                write=10.0,
                pool=5.0,
            )
            
            async with httpx.AsyncClient(timeout=timeout_config) as httpx_client:
                # Discover Email Writer Agent
                try:
                    self.writer_card = await self._get_agent_card(self.email_writer_url, httpx_client)
                    print(f"{Fore.GREEN}✅ {self.writer_card.name}: {self.writer_card.description}{Style.RESET_ALL}")
                except Exception as e:
                    print(f"{Fore.RED}❌ Failed to discover Email Writer Agent: {e}{Style.RESET_ALL}")
                
                # Discover Email Reviewer Agent
                try:
                    self.reviewer_card = await self._get_agent_card(self.email_reviewer_url, httpx_client)
                    print(f"{Fore.GREEN}✅ {self.reviewer_card.name}: {self.reviewer_card.description}{Style.RESET_ALL}")
                except Exception as e:
                    print(f"{Fore.RED}❌ Failed to discover Email Reviewer Agent: {e}{Style.RESET_ALL}")
            
            print(f"{Fore.CYAN}🤖 Intelligent A2A Email Assistant ready!{Style.RESET_ALL}\n")
            
        except Exception as e:
            print(f"{Fore.RED}❌ Agent discovery failed: {e}{Style.RESET_ALL}")
            raise
    
    def _is_email_request(self, user_input: str) -> bool:
        """Determine if user input is requesting email writing."""
        email_keywords = [
            'write email', 'draft email', 'compose email', 'send email',
            'email to', 'write to', 'draft to', 'compose to',
            'meeting request', 'leave request', 'follow up', 'apology',
            'thank you email', 'reminder email', 'invitation', 'email for',
            'need email', 'create email', 'help me write'
        ]
        user_lower = user_input.lower()
        return any(keyword in user_lower for keyword in email_keywords)
    
    def _handle_general_query(self, user_input: str) -> str:
        """Handle general questions that don't require agents."""
        user_lower = user_input.lower()
        
        if 'what is ai' in user_lower or 'what is artificial intelligence' in user_lower:
            return """🤖 **Artificial Intelligence (AI)** is a branch of computer science that focuses on creating systems capable of performing tasks that typically require human intelligence. This includes:

• **Machine Learning** - Systems that learn from data
• **Natural Language Processing** - Understanding and generating human language
• **Computer Vision** - Interpreting visual information
• **Reasoning & Problem Solving** - Making decisions based on available information

AI is used in various applications like virtual assistants, recommendation systems, autonomous vehicles, and agent-to-agent communication systems like this one!"""
        
        elif any(greeting in user_lower for greeting in ['how are you', 'hello', 'hi', 'hey']):
            return f"👋 Hello! I'm your intelligent A2A Email Assistant. I can help you write professional emails automatically using specialized agents. Just tell me what email you need!"
        
        elif 'help' in user_lower:
            return """🆘 **Available Commands:**
• Simply describe the email you need (e.g., "write email to manager about leave")
• Ask general questions (e.g., "what is AI")
• Type 'agents' to see connected agents
• Type 'quit' to exit

I'll automatically handle the email writing and review process for you!"""
        
        elif 'thank you' in user_lower or 'thanks' in user_lower:
            return "🙏 You're welcome! Happy to help with your email needs anytime."
        
        else:
            return "🤔 I'm not sure how to help with that. Try asking me to write an email or ask a general question!"
    
    async def process_user_request(self, user_input: str) -> str:
        """Intelligently process user request - the main entry point."""
        
        # Check if this is an email writing request
        if self._is_email_request(user_input):
            if not self.writer_card:
                return "❌ Email Writer Agent is not available. Please check if the agent is running on port 8001."
            
            print(f"{Fore.CYAN}🔄 Detected email request - starting automated A2A workflow...{Style.RESET_ALL}")
            
            try:
                # Step 1: Generate email draft
                print(f"{Fore.BLUE}Step 1: Writing email via A2A Writer Agent...{Style.RESET_ALL}")
                email_draft = await self._send_message_to_agent(self.email_writer_url, user_input)
                
                if not email_draft or email_draft == 'No response received':
                    return "❌ Failed to get response from Email Writer Agent."
                
                # Step 2: Review the email (if reviewer is available)
                if self.reviewer_card:
                    print(f"{Fore.BLUE}Step 2: Reviewing email via A2A Reviewer Agent...{Style.RESET_ALL}")
                    review_request = f"Please review this email and suggest improvements:\n\n{email_draft}"
                    email_review = await self._send_message_to_agent(self.email_reviewer_url, review_request)
                    
                    # Step 3: Return comprehensive result
                    result = f"""✅ **EMAIL GENERATED & REVIEWED**

📧 **DRAFT EMAIL:**
{email_draft}

📋 **REVIEW FEEDBACK:**
{email_review}

🎯 **Ready to send!** The email has been automatically written and reviewed by specialized A2A agents."""
                    
                    return result
                else:
                    # Only writer available
                    result = f"""✅ **EMAIL GENERATED**

📧 **DRAFT EMAIL:**
{email_draft}

🎯 **Ready to send!** The email has been written by the A2A Email Writer Agent.
⚠️ Note: Email Reviewer Agent is not available for review."""
                    
                    return result
                    
            except Exception as e:
                logger.error(f"Error in email workflow: {e}")
                return f"❌ Error processing email request: {e}"
        
        else:
            # Handle general queries directly
            return self._handle_general_query(user_input)
    
    async def interactive_mode(self):
        """Intelligent interactive mode - automatically routes requests."""
        print(f"\n{Fore.GREEN}🎯 Intelligent A2A Email Assistant{Style.RESET_ALL}")
        print("=" * 60)
        print("💡 Just tell me what you need! I'll automatically:")
        print("   • Write emails using specialized agents")
        print("   • Review emails for quality")
        print("   • Answer general questions directly")
        print("   • Type 'agents' to see available agents")
        print("   • Type 'quit' to exit")
        print()
        
        while True:
            try:
                user_input = input(f"{Fore.CYAN}Smart Client >{Style.RESET_ALL} ").strip()
                
                if user_input.lower() == 'quit':
                    print(f"{Fore.YELLOW}👋 Goodbye!{Style.RESET_ALL}")
                    break
                
                elif user_input.lower() == 'agents':
                    await self.show_agent_info()
                
                elif user_input:
                    # Process any user request intelligently
                    response = await self.process_user_request(user_input)
                    print(f"\n{Fore.GREEN}{response}{Style.RESET_ALL}\n")
                
                else:
                    print(f"{Fore.YELLOW}Please enter a request or question!{Style.RESET_ALL}")
                    
            except KeyboardInterrupt:
                print(f"\n{Fore.YELLOW}👋 Goodbye!{Style.RESET_ALL}")
                break
            except Exception as e:
                print(f"{Fore.RED}❌ Error: {e}{Style.RESET_ALL}")
    
    async def show_agent_info(self):
        """Show information about discovered A2A agents."""
        print(f"\n{Fore.CYAN}🤖 Connected A2A Agents:{Style.RESET_ALL}")
        print("=" * 50)
        
        # Email Writer Agent info
        if self.writer_card:
            print(f"{Fore.GREEN}📧 {self.writer_card.name}{Style.RESET_ALL}")
            print(f"   Description: {self.writer_card.description}")
            print(f"   Version: {self.writer_card.version}")
            if hasattr(self.writer_card, 'skills') and self.writer_card.skills:
                print(f"   Skills: {[skill.name for skill in self.writer_card.skills]}")
            print()
        else:
            print(f"{Fore.RED}📧 Email Writer Agent - Not Available{Style.RESET_ALL}")
            print()
        
        # Email Reviewer Agent info
        if self.reviewer_card:
            print(f"{Fore.GREEN}🔍 {self.reviewer_card.name}{Style.RESET_ALL}")
            print(f"   Description: {self.reviewer_card.description}")
            print(f"   Version: {self.reviewer_card.version}")
            if hasattr(self.reviewer_card, 'skills') and self.reviewer_card.skills:
                print(f"   Skills: {[skill.name for skill in self.reviewer_card.skills]}")
            print()
        else:
            print(f"{Fore.RED}🔍 Email Reviewer Agent - Not Available{Style.RESET_ALL}")
            print()
    
    async def demonstrate_a2a_system(self):
        """Demonstrate the intelligent A2A email system."""
        print(f"\n{Fore.CYAN}🎭 Intelligent A2A Email System Demo{Style.RESET_ALL}")
        print("=" * 70)
        print("This demo shows intelligent routing and automated A2A workflows")
        print()
        
        # Demo scenarios - mix of email and general requests
        scenarios = [
            "What is AI?",
            "Write a professional meeting request email for next Tuesday",
            "How are you?",
            "Draft an apology email to a client for delayed shipment",
            "Help me write email to manager about taking leave for my sister's wedding"
        ]
        
        for i, scenario in enumerate(scenarios, 1):
            print(f"\n{Fore.YELLOW}Demo Scenario {i}:{Style.RESET_ALL}")
            print(f"Request: {scenario}")
            print("-" * 80)
            
            try:
                # Process each request intelligently
                response = await self.process_user_request(scenario)
                print(f"\n{Fore.GREEN}{response}{Style.RESET_ALL}")
                print(f"\n{Fore.CYAN}{'='*80}{Style.RESET_ALL}")
                
                # Wait between demos
                await asyncio.sleep(3)
                
            except Exception as e:
                print(f"{Fore.RED}❌ Demo {i} failed: {e}{Style.RESET_ALL}")


@click.command()
@click.option('--demo', is_flag=True, help='Run automated intelligent A2A demo')
@click.option('--interactive', is_flag=True, help='Start intelligent interactive mode')
def main(demo: bool, interactive: bool):
    """Intelligent A2A Email Client - Automatically routes requests and orchestrates workflows."""
    
    async def run():
        client = A2AIntelligentClient()
        
        try:
            await client.initialize()
            
            if demo:
                await client.demonstrate_a2a_system()
            elif interactive:
                await client.interactive_mode()
            else:
                print(f"{Fore.YELLOW}Use --demo for automated demo or --interactive for interactive mode{Style.RESET_ALL}")
                await client.demonstrate_a2a_system()  # Default to demo
                
        except Exception as e:
            print(f"{Fore.RED}❌ A2A Client failed: {e}{Style.RESET_ALL}")
    
    asyncio.run(run())


if __name__ == '__main__':
    main()