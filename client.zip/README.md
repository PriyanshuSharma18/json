# A2A Demo: Agent-to-Agent Communication

This is a complete demonstration of **Agent-to-Agent (A2A) communication** using the A2A protocol with Azure OpenAI integration. This demo showcases how independent AI agents can discover, communicate, and collaborate with each other.

## 🎯 What This Demo Shows

### Core A2A Concepts Demonstrated:
1. **Agent Discovery**: Agents can discover each other's capabilities through agent cards
2. **Standardized Communication**: JSON-RPC based protocol for reliable agent communication  
3. **Agent Specialization**: Different agents optimized for specific tasks
4. **Agent Chaining**: Agents can work together in sequence to complete complex workflows
5. **Real-time Streaming**: Support for streaming responses

### Demo Agents:
- **Echo Agent** (Port 8001): Enhances user messages with AI-powered commentary
- **Reviewer Agent** (Port 8002): Provides comprehensive text analysis and feedback

## 🏗️ Architecture

```
┌─────────────────┐    A2A Protocol    ┌─────────────────┐
│   Echo Agent    │◄──────────────────►│ Reviewer Agent  │
│   (Port 8001)   │                    │   (Port 8002)   │
└─────────────────┘                    └─────────────────┘
         ▲                                       ▲
         │              A2A Protocol             │
         └────────────────┬──────────────────────┘
                          │
                   ┌─────────────┐
                   │ Demo Client │
                   │  (A2A SDK)  │
                   └─────────────┘
```

## 📋 Prerequisites

- **Python 3.8+** 
- **Azure OpenAI Account** with API access
- **Internet Connection** for package installation

## ⚡ Quick Start

### Option 1: Automated Setup (Recommended)

1. **Windows PowerShell**:
   ```powershell
   .\run_demo.ps1
   ```

2. **Python (Cross-platform)**:
   ```bash
   python run_demo.py
   ```

### Option 2: Manual Setup

1. **Install Dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

2. **Configure Environment**:
   Ensure your `.env` file contains your Azure OpenAI credentials (already configured).

3. **Start Echo Agent**:
   ```bash
   cd agents/echo_agent
   python __main__.py
   ```

4. **Start Reviewer Agent** (in new terminal):
   ```bash
   cd agents/reviewer_agent  
   python __main__.py
   ```

5. **Run Demo Client** (in third terminal):
   ```bash
   cd client
   python demo_client.py --demo
   ```

## 🎬 Demo Scenarios

### Scenario 1: Direct Agent Communication
- Client sends message to Echo Agent
- Echo Agent enhances the message with AI commentary
- Demonstrates basic A2A request-response pattern

### Scenario 2: Text Analysis
- Client sends text to Reviewer Agent
- Reviewer Agent provides detailed analysis (grammar, style, clarity)
- Shows specialized agent capabilities

### Scenario 3: Agent Chaining
- Client → Echo Agent (message enhancement)
- Echo Agent response → Reviewer Agent (quality analysis)
- Demonstrates multi-agent workflows

## 🔧 Configuration

### Environment Variables (.env)
```bash
# Azure OpenAI Configuration
AZURE_OPENAI_API_KEY="your-api-key"
AZURE_OPENAI_ENDPOINT="your-endpoint"
AZURE_OPENAI_API_VERSION="2024-12-01-preview"
AZURE_OPENAI_DEPLOYMENT_NAME="gpt-4o"

# Agent URLs
ECHO_AGENT_URL=http://localhost:8001
REVIEWER_AGENT_URL=http://localhost:8002
```

### Agent Ports
- Echo Agent: `localhost:8001`
- Reviewer Agent: `localhost:8002`

## 📡 A2A Protocol Features Demonstrated

### 1. Agent Cards
Each agent exposes its capabilities via a standard agent card:
```
GET http://localhost:8001/.well-known/agent-card.json
```

### 2. Message Exchange
Standardized JSON-RPC message format:
```json
{
  "jsonrpc": "2.0",
  "method": "message/send", 
  "params": {
    "id": "task-id",
    "message": {
      "kind": "message",
      "role": "user",
      "parts": [{"kind": "text", "text": "Hello"}]
    }
  }
}
```

### 3. Streaming Support
Both agents support real-time streaming responses for better user experience.

## 🎯 Key Benefits for Presentation

### Technical Benefits:
- **Interoperability**: Agents from different developers can communicate seamlessly
- **Scalability**: Add new specialized agents without modifying existing ones  
- **Reliability**: Standardized protocol ensures consistent communication
- **Enterprise Ready**: Built on proven JSON-RPC standards

### Business Benefits:
- **Specialization**: Each agent can focus on what it does best
- **Flexibility**: Easy to compose different agent combinations
- **Extensibility**: New capabilities via new agents, not code changes
- **Cost Efficiency**: Reuse specialized agents across multiple workflows

## 🔍 What Happens During Demo

1. **Initialization Phase**:
   - Both agents start and expose their capabilities
   - Client discovers agents via agent card endpoints
   - Establishes A2A communication channels

2. **Communication Phase**:
   - Demonstrates direct agent-to-client communication
   - Shows agent-to-agent relay communication
   - Exhibits streaming response capabilities

3. **Integration Phase**:
   - Shows how agents can work together in workflows
   - Demonstrates the power of specialized agent collaboration

## 🛠️ Troubleshooting

### Common Issues:

1. **"Module not found" errors**:
   ```bash
   pip install -r requirements.txt
   ```

2. **Port already in use**:
   - Change ports in `.env` file
   - Kill existing processes: `netstat -ano | findstr :8001`

3. **Azure OpenAI errors**:
   - Verify API key and endpoint in `.env`
   - Check Azure OpenAI deployment name

4. **Agent not responding**:
   - Ensure agents are fully started (check console output)
   - Verify agent health: `curl http://localhost:8001/.well-known/agent-card.json`

### Logs and Debugging:
- Agent logs appear in their respective terminal windows
- Client logs show communication details
- Enable debug logging by setting `logging.basicConfig(level=logging.DEBUG)`

## 📚 For Further Learning

- [A2A Protocol Specification](https://github.com/a2aproject/a2a-samples)
- [Azure OpenAI Documentation](https://docs.microsoft.com/azure/cognitive-services/openai/)
- [A2A Python SDK Documentation](https://github.com/a2aproject/a2a-samples/tree/main/samples/python)

## 🎉 Presentation Key Points

1. **"This is NOT just chatbots talking to each other"**
   - This is a standardized protocol for AI agent interoperability
   - Enables building complex multi-agent systems

2. **"Real-world enterprise applications"**
   - Customer service (routing → specialist agents)
   - Content creation (writer → reviewer → publisher agents)
   - Data processing (collector → analyzer → reporter agents)

3. **"Future-proof architecture"**
   - Standard protocol means agents from different vendors can work together
   - Easy to add new capabilities without rebuilding existing systems

## 📄 License

This demo is based on the A2A samples repository and follows the same licensing terms.

---

**Ready to explore the future of multi-agent AI systems? Run the demo and see A2A in action!** 🚀