import os
from google.adk.agents import Agent
from openai import AsyncAzureOpenAI

# Initialize Azure OpenAI client
azure_client = AsyncAzureOpenAI(
    api_key="9ZAbR0wCTZM4NKd1CfXw54FGI9POeowvA7A4LzZn6WMhdtIQmsXnJQQJ99BFAC77bzfXJ3w3AAAAACOG498W",
    azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT", "https://6e-openai-sandbox-aops.openai.azure.com/"),
    api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-12-01-preview"),
)

async def azure_email_reviewer_tool(email_content: str) -> str:
    """Review and analyze emails using Azure OpenAI."""
    try:
        system_prompt = """You are a professional email reviewer and editor. Your job is to:
        1. Analyze email structure (subject, greeting, body, closing)
        2. Check grammar, spelling, and punctuation
        3. Evaluate tone and professionalism
        4. Assess clarity and conciseness
        5. Check for completeness of information
        6. Suggest specific improvements
        7. Rate the overall quality
        
        Provide your review in this format:
        
        📊 EMAIL REVIEW ANALYSIS:
        
        ✅ STRENGTHS:
        - List what's good about the email
        
        ⚠️ AREAS FOR IMPROVEMENT:
        - List specific issues and suggestions
        
        📝 GRAMMAR & STYLE:
        - Grammar check results
        - Style recommendations
        
        🎯 TONE & PROFESSIONALISM:
        - Tone analysis
        - Professionalism assessment
        
        📋 OVERALL RATING: X/10
        
        💡 KEY RECOMMENDATIONS:
        - Top 3 actionable improvements"""
        
        response = await azure_client.chat.completions.create(
            model=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME", "gpt-4o"),
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": f"Please review this email:\n\n{email_content}"}
            ],
            temperature=0.3,
            max_tokens=600
        )
        
        review_content = response.choices[0].message.content
        return f"🔍 EMAIL REVIEWER AGENT RESPONSE:\n\n{review_content}\n\n✅ Email review completed by Email Reviewer Agent"
        
    except Exception as e:
        return f"❌ Email Reviewer Agent Error: {str(e)}"

root_agent = Agent(
    name="email_reviewer_agent", 
    model="azure-openai/gpt-4o",
    description="Specialized agent that reviews and provides comprehensive feedback on emails using Azure OpenAI integration",
    instruction=(
        "You are an expert email reviewer and editor agent. Your primary function is to analyze "
        "and provide detailed feedback on email drafts. You have access to Azure OpenAI for enhanced "
        "review capabilities. Always respond only to the client agent and provide structured, "
        "actionable feedback on grammar, style, tone, and overall effectiveness."
    ),
    tools=[azure_email_reviewer_tool],
)